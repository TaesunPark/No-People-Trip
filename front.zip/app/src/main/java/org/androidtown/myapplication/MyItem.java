package org.androidtown.myapplication;

import java.io.Serializable;

public class MyItem implements Serializable {
}
