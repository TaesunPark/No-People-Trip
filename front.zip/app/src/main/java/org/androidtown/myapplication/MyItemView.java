package org.androidtown.myapplication;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyItemView extends RecyclerView.ViewHolder {
    public MyItemView (@NonNull View itemView){
        super(itemView);
    }
}
